﻿using System;

namespace EJ01
{
    class Program
    {
        static void Main(string[] args)
        {
            
            // Uso de los constructores
            
                 
            

            Console.ReadKey();

        }
    }
}
