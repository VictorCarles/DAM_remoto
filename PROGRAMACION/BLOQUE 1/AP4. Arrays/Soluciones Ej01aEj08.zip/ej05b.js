/* 
EJERCICIO 5.
Desarrollar un programa en el que se pidan al usuario dos arrays de números enteros 
e indique en pantalla el producto de los elementos que ocupan la misma posición. 
En la petición de cada array, la introducción de elementos terminará cuando se suministre el valor cero (0).
Si los Arrays proporcionados no tienen la misma longitud, se ha de escribir 
en pantalla un mensaje indicativo y no se realizará el proceso. 

Variación del ejercicio ej05a. Se utiliza una función para rellenar y cargar los elementos de
los arrays. Se reutiliza código.
*/

// Función que carga y devuelve los elementos de un array. 
function cargaElementos() {
    let arr = [];
    let i = 0, elemento;
    do {
        elemento = readlineSync.questionInt('Dime el elemento ' + (i + 1) + ': ');
        if (elemento != 0) {
            arr[i] = elemento;
            i++;
        }
    } while (elemento != 0);
    return arr;
}

let readlineSync = require('readline-sync');

// visualizo los arrays en bruto para ver su contenido
console.log("Introduce elementos del Primer Array.");
let arr1=cargaElementos();
console.log("Introduce elementos del Segundo Array.");
let arr2=cargaElementos();

if (arr1.length != arr2.length) {
    console.log('El tamaño de los arrays es diferente.');
} else {
    console.log(arr1.toString()); // Visualizo el primer array
    console.log(arr2.toString()); // Visualizo el segundo array
    for (let j = 0; j < arr1.length; j++) {
        console.log('Producto de posicion ' + j + ': ' + arr1[j] * arr2[j]);
    }
}
