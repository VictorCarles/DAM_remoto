CREATE database BD CHARACTER SET latin1 COLLATE latin1_spanish_ci ;
SET storage_engine=INNODB;
USE BD;


 /* A character set is a set of symbols and encodings. 
A collation is a set of rules for comparing characters in a character set. */

/* En palabras muy breves, una de las principales diferencias es que CHARSET hace referencia a c�mo MySQL guarda 
internamente el dato y COLLATION es una manera de decirle c�mo debe comparar el texto y/o ordenarlo.  */

SHOW CHARACTER SET;



/*  cabe destacar que podemos asignar COLLATIONs y CHARSETs; en orden de prioridad; a nivel de:

MySQL completo
Bases de datos
Tablas
Campos

Eso significa que si se asigna un CHARSET y COLLATION a nivel de MySQL, todas las bases de datos heredar�n esta propiedad. 
A su vez, todas las tablas heredar�n las propiedades de la base de datos y asimismo, 
todos los campos heredar�n las propiedades predeterminadas de las tablas. 
En cualquiera de estos pasos podemos sobre-escribir el predeterminado con nuestro propio CHARSET y COLLATION.

*/