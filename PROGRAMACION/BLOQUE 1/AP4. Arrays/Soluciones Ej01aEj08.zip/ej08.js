/* 
EJERCICIO 8.
Desarrollar un programa en el que se pidan al usuario un array de números enteros 
-hasta que se introduzca el número -1 que no formará parte del array-. 
Tras visualizar todos los números introducidos, debe indicar si dicho vector es capicúa,
es decir, la secuencia de sus elementos es igual vista de delante hacia atrás 
y de detrás hacia delante.
*/

function esCapicuaAlt(vector) {
    let copia = [];
    copia = vector.slice();     // copio el array vector en copia.
    copia.reverse();            // intercambio todos los elementos de copia.
    
    // Comparo uno a uno los elementos de copia y vector para ver si son iguales
    for(let i=0;i<=vector.length;i++) {
        if (vector[i]!==copia[i])
            return false;
    }
    return true;
}

function esCapicua(vector) {

    let ultimoElemento = vector.length-1; // guardo la posición del último elemento
    for(let pos=0;pos<vector.length;pos++) {
        if (vector[pos]!=vector[ultimoElemento-pos]) 
            return false;
    }
    return true; // lo ejecutará si no ha entrado ninguna vez en el if.    
}

let arrayNumeros= [];
let readlineSync = require('readline-sync');
let i=0; 
let continuar = true; // interruptor para controlar el bucle.

// Petición de elementos del array.
do {
        arrayNumeros[i] = readlineSync.questionInt('Introduce numero. \'-1\' para terminar: ');
        if (arrayNumeros[i]==-1) {
            continuar=false;// cambio el interruptor para terminar el bucletermino el bucle 
        }
        i++;
} while (continuar);
// elimino el último elemento introducido (que es -1)
// Otra forma podría ser es arrayNumeros.length = arrayNumeros.length - 1
arrayNumeros.pop(); 
console.log(arrayNumeros); // visualizo el array.

// comprobación de si el ARRAY es capicua.
if (esCapicua(arrayNumeros)) {          // aquí podríamo utilizar también la función esCapicuaAlt()
    console.log('El array es CAPICUA');
} else {
    console.log('El array NO es CAPICUA');
}


