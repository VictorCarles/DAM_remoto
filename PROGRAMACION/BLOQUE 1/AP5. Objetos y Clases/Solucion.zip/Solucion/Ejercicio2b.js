/* La diferencia de este ejercicio con respecto a la versión A, es que el método ladrar()
de la clase Perro no devuelve en un string el tipo de ladrido, sino que dicho método
se encarga de visualizar directamente el tipo de ladrido y la información del perro. */

class Perro {

    constructor(nombre, raza, talla) {
        this.nombre = nombre;
        this.raza = raza;
        this.talla = talla;
    }

    ladrar() {
        if (this.talla <= 50) {
            console.log("Soy un " + this.raza + " y ladro así: ¡¡¡ Guauuuuu !!!")
        } else {
            console.log("Soy un " + this.raza + " y ladro así: ¡¡¡ Buff... Buff !!!")
        }
    }

}

// Programa principal
// Instanciamos tres objetos de la clase Perro.
let perro1 = new Perro("luis","Doberman",56);
let perro2 = new Perro("Coque","Ratonera",23);
let perro3 = new Perro("Blanco","Hasky Siberiano",67);
// Hacemos ladrar a cada uno de los objetos instanciados para que nos informe de su
// información y su tipo de ladrido.
perro1.ladrar();
perro2.ladrar();
perro3.ladrar();