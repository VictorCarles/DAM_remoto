
class Persona {

    constructor(nom,años) {
        this.nombre = nom;
        this.edad = años;
        if (this.edad>=67) {
            this.jubilada = true;
        } else {
            this.jubilada = false;
        }
        // Otra forma más límpia de asignar el valor del atributo jubilada
        // this.jubilada = (this.edad>=67)?true:false;
    }

    cumplirAños() {
        // Incrementamos la edad de la persona.
        this.edad++;
        // visualizamos la información de la nueva edad
        console.log(this.nombre + ' tiene ' + this.edad + ' años');
        // Si la personas no está jubilada y acaba de cumplir 67 años,
        // cambiamos el atributo jubilada a true e informamos de la jubilación
        if (!this.jubilada && this.edad==67) {
            this.jubilada = true;
            console.log('Acabas de Jubilarte');
        }
    }
}

// Instanciamos una variable p1 de la clase Persona. 
// El objeto p1 tendrá como nombre Pedro y 60 años de edad
let p1 = new Persona('Pedro',60);
// Hacemos que la persona (p1) cumpla 10 años consecutivos (uno tras otro)
// Cuando cumpla 67 años debe de jubilarse e informar de ello.
// A partir de que cumpla 67 años, su atributo jubilada permanecerá a true siempre. 
for (let i=1; i<=10; i++) {
    p1.cumplirAños();
}

