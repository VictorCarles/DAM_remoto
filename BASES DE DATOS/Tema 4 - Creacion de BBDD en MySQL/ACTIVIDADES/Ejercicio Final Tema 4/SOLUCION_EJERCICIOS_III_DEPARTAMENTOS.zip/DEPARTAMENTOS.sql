CREATE DATABASE Departamentos0 CHARACTER SET utf8;
SET storage_engine=INNODB;
USE Departamentos0;

CREATE TABLE Empleados
(NUM_EMP int(3) not null,
nombre varchar(50) not null,
fecha_nacimiento date,
fecha_ingreso date not null,
telf_empl int(8) not null,
salario decimal(10,2) not null,
comision decimal(10,2) ,
num_hijos int(1),
tipo enum('fijo','eventual') not null, 
NUM_DPTO int(3),
PRIMARY KEY (NUM_EMP)
);


CREATE TABLE Departamentos
(NUM_DPTO int(3) not null,
nombre varchar(50) not null,
presupuesto decimal(10,2) not null,
NUM_CENTRO int(3),
PRIMARY KEY (NUM_DPTO)
);


CREATE TABLE Centros
(NUM_CENTRO int(3) not null,
nombre varchar(50) not null,
direccion varchar(40) not null,
localidad varchar(40) not null,
provincia varchar(30) not null,
PRIMARY KEY (NUM_CENTRO)
);


ALTER TABLE Empleados ADD CONSTRAINT empl FOREIGN KEY (NUM_DPTO) REFERENCES Departamentos (NUM_DPTO) ON DELETE SET NULL;
ALTER TABLE Departamentos ADD CONSTRAINT dept FOREIGN KEY (NUM_CENTRO) REFERENCES Centros (NUM_CENTRO) ON DELETE SET NULL;


INSERT INTO Centros VALUES (001, 'Zona Sur', 'C/.Miraflores s/n', 'Sevilla', 'Sevilla');
INSERT INTO Centros VALUES (002, 'Zona Centro', 'Avda. Felipe II, 4', 'Dos Hermanas', 'Sevilla');

INSERT INTO Departamentos VALUES (005, 'Reparaciones', 150000, 001);
INSERT INTO Departamentos VALUES (010, 'Ventas', 200000, 002);

INSERT INTO Empleados VALUES (001, 'Juan P�ez', "1960-10-25", "1980-10-25",954858691, 10000, 500, 0, 'fijo', 005);
INSERT INTO Empleados VALUES (002, 'Rosa Gil', "1965-12-25", "1989-10-25", 954668221, 12000, 1500, 1, 'fijo', 010);




