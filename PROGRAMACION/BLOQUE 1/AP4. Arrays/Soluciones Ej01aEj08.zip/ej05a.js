/* 
EJERCICIO 5.
Desarrollar un programa en el que se pidan al usuario dos arrays de números enteros 
e indique en pantalla el producto de los elementos que ocupan la misma posición. 
En la petición de cada array, la introducción de elementos terminará cuando se suministre el valor cero (0).
Si los Arrays proporcionados no tienen la misma longitud, se ha de escribir 
en pantalla un mensaje indicativo y no se realizará el proceso. 
*/

let readlineSync = require('readline-sync');

// introducción del 1er array
let arr1 = [];
let  i=0;
console.log('Introduccion de elementos del PRIMER ARRAY');
do {
    elemento = readlineSync.questionInt('Dime el elemento ' + (i+1) + ': ');
    if (elemento!=0) {
        arr1[i]=elemento;
        i++;
    }
} while(elemento!=0);

// introducción del 2º array
let arr2 = [];
i=0;
console.log('Introduccion de elementos del SEGUNDO ARRAY');
do {
    elemento = readlineSync.questionInt('Dime el elemento ' + (i+1) + ': ');
    if (elemento!=0) { 
        arr2[i]=elemento;
        i++;
    }
} while(elemento!=0);

// visualizo los arrays en bruto para ver su contenido
console.log(arr1);
console.log(arr2);

if(arr1.length != arr2.length) {
    console.log('Eltamaño de los arrays es diferente');
} else {
    for (let j=0; j<arr1.length;j++) {
        console.log('Producto de posicion ' + j + ': ' + arr1[j]*arr2[j]);
    }
}
