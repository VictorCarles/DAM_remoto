// inclusión de la librería readline-sync
let Readlinesync = require("readline-sync");

// Definición de la clase Persona
class Persona {

    // Constructor de la clase
    // Recibe el nombre, edad, sexo, peso y altura.
    constructor(nom,ed,sex,pes,alt) {
        this.nombre = nom;
        this.edad = ed;
        this.dni = this.generarNIF();
        if (sex == 'M' || sex =='m') 
            this.sexo = "mujer";
        else
            this.sexo = "hombre";
        this.peso = pes;
        this.altura = alt;
    }

    // Devuelve un NIF válido para una persona (8 dígitos + 1 letra)
    // Este sería un método privado de la Clase Persona que sólo debería ser utilizado desde ella.
    generarNIF() {
        let digito = "";
        let tablaLetras = ['T','R','W','A','G','M','Y','F','P','D','X','B',
                          'N','J','Z','S','Q','V','H','L','C','K','E']; 
        let pos;

        for (let i=1;i<=8;i++) {
            digito += Math.trunc(Math.random()*10);
        }
        
        pos = Number(digito) % 23;
        return digito.toString() + tablaLetras[pos];
    }

    // Devuelve un string con el estado de la persona respecto a su peso
    calcularIMC() {
        let imc = (this.peso / this.altura**2);
        if (imc<18.5) {
            return "un peso bajo"
        } else if (imc<25) {
            return "un peso normal"
            } else {
                return "sobrepeso"
            }     
    
    }

    // Devuelve un valor booleano indicando si es mayor de edad (true o false) 
    esMayorDeEdad() {
       /*  if (this.edad>=18) {
            return true;
        } else {
            return false;
        } */
        // Otra forma más directa:
        return (this.edad>=18)?true:false; 
    }

    // comprueba si el sexo recibido como parámetro concuerda con el de la persona.
    comprobarSexo(dato) {
        if (dato==this.sexo) {
            console.log('Sexo Correcto');
            // podría devolver true (no queda claro en el enunciado si pide informar y retornar)
        } else {
            console.log('Sexo Incorrecto');
            // podría devolver false (no queda claro en el enunciado si pide informar y retornar)
        }
    }
    
    // Devuelve un string todos los datos de la persona para que sea visualizado
    // Cuando se haga la llamada al método retornará toda la información que 
    // deberá ser visualizada.
    informa() {
        let info;
        info = "\n\nNombre: " + this.nombre + "\tDni: " + this.dni + "\n";
        info +=  "Edad: " + this.edad + "\tSexo: " + this.sexo + "\n";
        info +=  "Peso: " + this.peso + "\tAltura: " + this.altura + "\n";
        return info;
    }
} 

// Función Pausa: Detiene la ejecución en espera de pulsar <intro>
function pausa() {
    Readlinesync.question('\n\nPulsa <intro> para continuar.')
    console.clear();
}


// Declaración de variables globales.
let nombre="", edad, sexo, peso, altura, per1;
let salir = false;

do {

    // Pido el nombre de la persona
    nombre = Readlinesync.question("Dime el nombre: ");
    nombre = nombre.toUpperCase(); // convierto el nombre a mayúsculas

    if (nombre != 'FINALIZAR') {
        // Pido los datos básicos de la persona. En primer lugar la edad (el nombre ya lo he pedido)
        edad = Readlinesync.questionInt("Dime la edad: ");
        // En el caso del sexo valido que sea 'H' o 'M', o en caso contrario lo vuelvo a pedir
        do {
          sexo = Readlinesync.question("Dime el sexo (H/M): ").toUpperCase();
          if (sexo=='H' || sexo =='M') salir=true; 
        } while (!salir);
        // Acabo la petición de datos con el peso y la altura. 
        // En este caso no valido nada, pero se podrían hacer validaciones.
        peso = Readlinesync.questionFloat("Dime el peso: ");
        altura = Readlinesync.questionFloat("Dime la altura: ");

        // instancio el objeto con el que vamos a trabajar (de la clase persona)
        // pasándole todos los datos necesarios por parámetro al constructor. 
        per1 = new Persona(nombre.toUpperCase(),edad,sexo,peso,altura);
        // Visualizo la información de la persona llamando a su método informa() y
        // visualizando su información de retorno.
        console.log(per1.informa());
        // Informamos del estado de peso de la persona llamando a su método calcularIMC()
        console.log(per1.nombre + " tiene " + per1.calcularIMC());
        // Informamos del si es mayor de edad o no haciendo uso de su método esMayorDeEdad()
        if (per1.esMayorDeEdad()) {
            console.log(per1.nombre + " es mayor de edad.");
        } else {
            console.log(per1.nombre + " es menor de edad.");
        }
        pausa();
    }    
} while (nombre != 'FINALIZAR');