
// Creamos la Clase Perro
class Perro {

    // método Constructor con atributos
    // recibe como parámetros el nombre, la raza y el tamaño.
    constructor(nom,rz,ta) {
        this.nombre = nom;
        this.raza = rz;
        this.talla = ta;
    }

    // método ladrar
    ladrar() {
        // Creo un array con todos los tipos de ladrido posibles hasta el momento.
        let tipoladrido = ["¡GUAUU GUAUU!","¡BUF BUF!"];
        let ladrido;

        // Otra opción: ladrido = (this.talla <= 50)?0:1; 
        if (this.talla <= 50) {
            ladrido = 0;    // tipo de ladrido corresponde al primer elemento del array (índice).
        } else {
            ladrido = 1;    // tipo de ladrido corresponde al segundo elemento del array (índice).
        }
        return tipoladrido[ladrido];
    }
}

// Instanciamos un objeto perro: Tobby/Labrador Retriever/talla 40
let dog1 = new Perro("Tobby","Labrador Retriever",40);
// Instanciamos un objeto perro: Coronel/Bulldog/talla 60
let dog2 = new Perro("Coronel","Bulldog",60);
// Hacemos ladrar a Tobby e informamos de sus datos (quien es, su raza y tipo de ladrido).
console.log("Me llamo",dog1.nombre,"soy un",dog1.raza,"y ladro así:",dog1.ladrar());
// Hacemos ladrar a Coronel e informamos de sus datos (quien es, su raza y tipo de ladrido).
console.log("Me llamo",dog2.nombre,"soy un",dog2.raza,"y ladro así:",dog2.ladrar())


