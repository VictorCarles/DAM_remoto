/* 
EJERCICIO 7.
Desarrollar un programa en el que se pidan al usuario dos vectores de marcas de 
coches y motos (Array coches y Array motos). 
En cada caso, el programa deberá preguntar si se desean introducir más marcas 
y finalizará la introducción de datos cuando se indique ‘N’.  
Una vez introducidos los datos, se debe construir el vector resultado de “concatenar” 
los vectores coches y motos, es decir, poner los elementos de motos a continuación
de los de coches en un nuevo vector (transportes), 
y finalmente se visualicen (en bruto) todos los elementos de la concatenación.


*/

function pideMarcas(dato) {

    let arr= [];
    let readlineSync = require('readline-sync');
    let i=0;
    console.log("\nMarcas de ",dato);
    do {
        arr[i] = readlineSync.question("Introduce marca ('N' para terminar): ");
        i++;
    } while (arr[i-1]!='N');
    arr.pop(); // elimino el último elemento introducido (que es N)
    return arr;
}

let coches = pideMarcas("coches");
console.log(coches); // visualizo en bruto el array de coches

let motos = pideMarcas("motos");
console.log(motos); // visualizo en bruto el array de motos

// copio el array coches al array transportes
let transportes =  [];
transportes = coches.slice(0);
// concateno el resto de elementos de motos en transportes
for(let j=0; j<motos.length;j++) {
    transportes.push(motos[j]);
}
console.log(transportes);  

// Investigar metodo CONCAT.
// transportes = transportes.concat(motos);  LINEAS 40 A 42

