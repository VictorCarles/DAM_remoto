/* 
EJERCICIO 6.
Crea dos Arrays de números positivos entre 0 y 20 que sean generados de forma aleatoria.
El tamaño de los Arrays debe ser de 10 elementos. 
Después, crea una función que reciba como parámetros los dos Arrays creados y 
devuelva un nuevo Array con la suma de la posición cero del array1 con el del array2 
y así sucesivamente hasta su último elemento. 
Por último, muestra el contenido de cada array (array1, array2 y el resultante
de la suma de los elementos de ambos).
*/

function sumaArrays(a1,a2) {
    let suma=[];
    for(j=0;j<10;j++) {
        suma[j]=a1[j]+a2[j];
    }
    return suma;
}

let array1 = new Array(), array2 = new Array();
for (i=0;i<10;i++) {
    array1[i] = Math.trunc(Math.random()*20);
    array2[i] = Math.trunc(Math.random()*20);
}

let nuevoArray = sumaArrays(array1,array2);
// visualizo en bruto los arrays para ver su estado.
console.log(array1.toString(),"\n");
console.log(array2.toString(),"\n");
console.log(nuevoArray.toString(),"\n");

